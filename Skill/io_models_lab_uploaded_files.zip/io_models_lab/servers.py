#!/usr/bin/env python3
"""
servers.py - Four TCP echo servers, one per I/O model.

    fork    : process-per-connection  (blocking I/O, os.fork)
    thread  : thread-per-connection   (blocking I/O, threading)
    select  : single process, I/O multiplexing with select()
    epoll   : single process, I/O multiplexing with epoll() (Linux)

All four implement the SAME application protocol: whatever bytes a client
sends are echoed back unchanged.  Using an identical, trivial workload means
that any difference in memory / CPU / latency comes from the I/O model itself.

Usage:
    python3 servers.py --model epoll --port 9000
"""
import argparse
import os
import resource
import select
import signal
import socket
import sys
import threading

RECV_SIZE = 4096
FD_SETSIZE_LIMIT = 1000   # select() cannot handle fds >= 1024 (FD_SETSIZE)


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def raise_nofile_limit():
    """Raise the open-file soft limit to the hard limit (one fd per client)."""
    soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
    target = 65536 if hard == resource.RLIM_INFINITY else hard
    try:
        resource.setrlimit(resource.RLIMIT_NOFILE, (target, hard))
    except (ValueError, OSError):
        pass


def make_listener(host, port, backlog):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((host, port))
    s.listen(backlog)
    return s


def blocking_echo(conn):
    """Echo loop used by the fork and thread models (blocking I/O)."""
    try:
        conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        while True:
            data = conn.recv(RECV_SIZE)      # blocks until data / EOF
            if not data:
                break
            conn.sendall(data)               # blocks until fully sent
    except OSError:
        pass
    finally:
        conn.close()


class Conn:
    """Per-connection state for the non-blocking (event driven) models."""
    __slots__ = ("sock", "out", "mask")

    def __init__(self, sock):
        self.sock = sock
        self.out = b""      # bytes still waiting to be sent
        self.mask = 0       # epoll event mask currently registered


def on_readable(c):
    """Read what is available and try to echo it. Returns False if closed."""
    try:
        data = c.sock.recv(RECV_SIZE)
    except BlockingIOError:
        return True
    except OSError:
        return False
    if not data:
        return False                          # peer closed
    if c.out:                                 # already backlogged -> queue
        c.out += data
        return True
    try:
        n = c.sock.send(data)
    except BlockingIOError:
        n = 0
    except OSError:
        return False
    if n < len(data):
        c.out = data[n:]
    return True


def on_writable(c):
    try:
        n = c.sock.send(c.out)
    except BlockingIOError:
        return True
    except OSError:
        return False
    c.out = c.out[n:]
    return True


def new_nonblocking_conn(listener):
    """accept() one connection, or return None if none is pending."""
    try:
        sock, _ = listener.accept()
    except (BlockingIOError, InterruptedError):
        return None
    except OSError:                           # e.g. EMFILE
        return None
    sock.setblocking(False)
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    return sock


# --------------------------------------------------------------------------
# Model 1: process-per-connection
# --------------------------------------------------------------------------
def run_fork(listener, _args):
    signal.signal(signal.SIGCHLD, signal.SIG_IGN)        # auto-reap children
    while True:
        try:
            conn, _ = listener.accept()
        except InterruptedError:
            continue
        except OSError:
            continue
        try:
            pid = os.fork()
        except OSError:                                  # out of processes
            conn.close()
            continue
        if pid == 0:                                     # ---- child ----
            listener.close()
            blocking_echo(conn)
            os._exit(0)
        conn.close()                                     # ---- parent ---


# --------------------------------------------------------------------------
# Model 2: thread-per-connection
# --------------------------------------------------------------------------
def run_thread(listener, args):
    if args.thread_stack_kb > 0:
        threading.stack_size(args.thread_stack_kb * 1024)
    while True:
        try:
            conn, _ = listener.accept()
        except OSError:
            continue
        try:
            threading.Thread(target=blocking_echo, args=(conn,),
                             daemon=True).start()
        except RuntimeError:                             # can't start thread
            conn.close()


# --------------------------------------------------------------------------
# Model 3: select()
# --------------------------------------------------------------------------
def run_select(listener, _args):
    listener.setblocking(False)
    conns = {}                                           # fd -> Conn
    while True:
        rlist = [listener] + [c.sock for c in conns.values()]
        wlist = [c.sock for c in conns.values() if c.out]
        readable, writable, _ = select.select(rlist, wlist, [])

        for s in readable:
            if s is listener:
                while True:
                    sock = new_nonblocking_conn(listener)
                    if sock is None:
                        break
                    if sock.fileno() >= FD_SETSIZE_LIMIT:
                        sock.close()                     # select() limit!
                        continue
                    conns[sock.fileno()] = Conn(sock)
            else:
                c = conns.get(s.fileno())
                if c is not None and not on_readable(c):
                    del conns[s.fileno()]
                    s.close()

        for s in writable:
            c = conns.get(s.fileno())
            if c is not None and c.out and not on_writable(c):
                del conns[s.fileno()]
                s.close()


# --------------------------------------------------------------------------
# Model 4: epoll()
# --------------------------------------------------------------------------
def run_epoll(listener, _args):
    listener.setblocking(False)
    ep = select.epoll()
    lfd = listener.fileno()
    ep.register(lfd, select.EPOLLIN)
    conns = {}                                           # fd -> Conn

    def close(fd):
        c = conns.pop(fd, None)
        if c is None:
            return
        try:
            ep.unregister(fd)
        except OSError:
            pass
        c.sock.close()

    while True:
        for fd, ev in ep.poll():
            if fd == lfd:
                while True:
                    sock = new_nonblocking_conn(listener)
                    if sock is None:
                        break
                    c = Conn(sock)
                    c.mask = select.EPOLLIN
                    conns[sock.fileno()] = c
                    ep.register(sock.fileno(), select.EPOLLIN)
                continue
            c = conns.get(fd)
            if c is None:
                continue
            alive = True
            if ev & select.EPOLLIN:
                alive = on_readable(c)
            if alive and (ev & select.EPOLLOUT):
                alive = on_writable(c)
            if alive and (ev & (select.EPOLLHUP | select.EPOLLERR)) \
                    and not (ev & select.EPOLLIN):
                alive = False
            if not alive:
                close(fd)
                continue
            want = select.EPOLLIN | (select.EPOLLOUT if c.out else 0)
            if want != c.mask:
                ep.modify(fd, want)
                c.mask = want


MODELS = {"fork": run_fork, "thread": run_thread,
          "select": run_select, "epoll": run_epoll}


def main():
    ap = argparse.ArgumentParser(description="I/O model echo server")
    ap.add_argument("--model", required=True, choices=MODELS)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=9000)
    ap.add_argument("--backlog", type=int, default=4096)
    ap.add_argument("--thread-stack-kb", type=int, default=0,
                    help="thread model only: stack size in KB (0 = OS default)")
    args = ap.parse_args()

    raise_nofile_limit()
    listener = make_listener(args.host, args.port, args.backlog)
    print(f"READY model={args.model} pid={os.getpid()} "
          f"port={args.port}", flush=True)
    try:
        MODELS[args.model](listener, args)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    if not sys.platform.startswith("linux"):
        sys.exit("This lab needs Linux (fork, epoll, /proc). Use WSL2 on Windows.")
    main()
