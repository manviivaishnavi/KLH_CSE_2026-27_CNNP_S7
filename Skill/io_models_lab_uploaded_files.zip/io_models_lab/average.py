"""average.py - averages the results_run*.csv files produced by benchmark.py."""
import csv
import glob
import collections

files = sorted(glob.glob("results_run*.csv"))
if not files:
    raise SystemExit("No results_run*.csv files found. "
                     "Run: python3 benchmark.py --out results_run1")

data = collections.defaultdict(list)
for f in files:
    for r in csv.DictReader(open(f)):
        data[(int(r["conns"]), r["model"])].append(r)

cols = [("idle_pss_mb", "PSS MB"), ("throughput_rps", "req/s"),
        ("lat_p99_ms", "p99 ms"), ("cpu_ms_per_req", "CPU ms/req")]

print("averages over", len(files), "runs")
print("%5s %-7s" % ("N", "model") + "".join("%12s" % h for _, h in cols))
for (n, m), rows in sorted(data.items()):
    vals = [sum(float(r[k]) for r in rows) / len(rows) for k, _ in cols]
    print("%5d %-7s" % (n, m) + "".join("%12.2f" % v for v in vals))
