#!/usr/bin/env python3
"""
loadgen.py - the COMMON WORKLOAD applied to every server model.

Workload definition
    * N clients each open ONE persistent TCP connection.
    * Phase 1 (connect): all N connections are opened and held idle.
      -> prints "CONNECTED <ok> <failed>".
    * Phase 2 (load): every client performs R request/response rounds.
      A request is a fixed-size message (default 64 B); the server echoes it.
      After each reply the client "thinks" for T ms (closed-loop workload).
    * Phase 3: prints one line "RESULT {json}" and waits for "CLOSE".

With --gated, benchmark.py drives the phases through stdin ("CONNECT", "GO",
"CLOSE") so memory can be sampled while all connections are open (idle) and
under load.  Without --gated it simply runs straight through, so it can also
be used by hand against any running server.
"""
import argparse
import asyncio
import json
import random
import socket
import sys
import time


def percentile(sorted_vals, p):
    if not sorted_vals:
        return 0.0
    k = min(len(sorted_vals) - 1, int(round(p / 100.0 * (len(sorted_vals) - 1))))
    return sorted_vals[k]


async def amain(a):
    loop = asyncio.get_running_loop()
    if a.gated:                                   # wait for "CONNECT"
        await loop.run_in_executor(None, sys.stdin.readline)
    sem = asyncio.Semaphore(a.connect_concurrency)
    streams = [None] * a.conns
    failed = 0

    async def connect(i):
        nonlocal failed
        async with sem:
            try:
                r, w = await asyncio.wait_for(
                    asyncio.open_connection(a.host, a.port), 15)
                sock = w.get_extra_info("socket")
                sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                streams[i] = (r, w)
            except Exception:
                failed += 1

    await asyncio.gather(*(connect(i) for i in range(a.conns)))
    live = [s for s in streams if s]
    print(f"CONNECTED {len(live)} {failed}", flush=True)
    if a.gated:
        await loop.run_in_executor(None, sys.stdin.readline)  # wait for GO

    msg = (b"x" * a.msg_size)
    think = a.think_ms / 1000.0
    latencies, errors = [], 0

    async def client(r, w):
        nonlocal errors
        await asyncio.sleep(random.random() * think)           # de-synchronise
        for _ in range(a.requests):
            t0 = time.perf_counter()
            try:
                w.write(msg)
                reply = await asyncio.wait_for(r.readexactly(a.msg_size), 15)
                if reply != msg:
                    raise ValueError("corrupt echo")
            except Exception:
                errors += 1
                return
            latencies.append(time.perf_counter() - t0)
            await asyncio.sleep(think)

    t_start = time.perf_counter()
    await asyncio.gather(*(client(r, w) for r, w in live))
    elapsed = time.perf_counter() - t_start

    lat = sorted(latencies)
    ms = 1000.0
    result = {
        "connected": len(live), "connect_failed": failed,
        "requests_ok": len(lat), "errors": errors,
        "elapsed_s": round(elapsed, 3),
        "throughput_rps": round(len(lat) / elapsed, 1) if elapsed else 0,
        "lat_avg_ms": round(sum(lat) / len(lat) * ms, 3) if lat else 0,
        "lat_p50_ms": round(percentile(lat, 50) * ms, 3),
        "lat_p95_ms": round(percentile(lat, 95) * ms, 3),
        "lat_p99_ms": round(percentile(lat, 99) * ms, 3),
        "lat_max_ms": round(lat[-1] * ms, 3) if lat else 0,
    }
    print("RESULT " + json.dumps(result), flush=True)
    if a.gated:
        await loop.run_in_executor(None, sys.stdin.readline)  # wait for CLOSE
    for r, w in live:
        w.close()


def main():
    ap = argparse.ArgumentParser(description="Common echo workload generator")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=9000)
    ap.add_argument("--conns", type=int, default=100)
    ap.add_argument("--requests", type=int, default=50,
                    help="request/response rounds per connection")
    ap.add_argument("--think-ms", type=float, default=50.0)
    ap.add_argument("--msg-size", type=int, default=64)
    ap.add_argument("--connect-concurrency", type=int, default=100)
    ap.add_argument("--gated", action="store_true",
                    help="synchronise phases via stdin (used by benchmark.py)")
    a = ap.parse_args()
    try:
        import resource
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        resource.setrlimit(resource.RLIMIT_NOFILE, (hard if hard > 0 else soft, hard))
    except Exception:
        pass
    asyncio.run(amain(a))


if __name__ == "__main__":
    main()
