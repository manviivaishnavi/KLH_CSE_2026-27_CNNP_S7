#!/usr/bin/env python3
"""
benchmark.py - runs every I/O model under the common workload, samples memory
and CPU of the whole server process tree through /proc, prints comparison
tables, a memory-budget analysis, and writes results.csv / results.json
(+ results.png if matplotlib is installed).

Metrics per (model, connections):
    RSS   sum of resident set sizes of server process tree (over-counts shared
          pages, e.g. after fork)
    PSS   proportional set size: shared pages divided among sharers -> the
          FAIR memory figure for multi-process servers
    procs / threads   peak number of processes / threads in the server
    throughput, latency (avg, p50, p95, p99, max), errors
    CPU   server CPU seconds consumed during the load phase
"""
import argparse
import csv
import json
import os
import queue
import resource
import signal
import subprocess
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
CLK_TCK = os.sysconf("SC_CLK_TCK")
MODELS = ["fork", "thread", "select", "epoll"]


# --------------------------------------------------------------------------
# /proc based sampling
# --------------------------------------------------------------------------
def _read(path):
    try:
        with open(path) as f:
            return f.read()
    except OSError:
        return None


def proc_table():
    """Return {pid: (ppid, cpu_ticks)} for every process."""
    table = {}
    for name in os.listdir("/proc"):
        if not name.isdigit():
            continue
        txt = _read(f"/proc/{name}/stat")
        if not txt:
            continue
        rest = txt.rsplit(")", 1)[1].split()   # comm may contain spaces
        table[int(name)] = (int(rest[1]), int(rest[11]) + int(rest[12]))
    return table


def cpu_seconds(pid, fallback_ticks):
    """Precise CPU time (ns resolution) from /proc/<pid>/task/*/schedstat.
    Falls back to the coarse 10 ms utime+stime ticks if unavailable."""
    total, ok = 0, False
    try:
        for tid in os.listdir(f"/proc/{pid}/task"):
            txt = _read(f"/proc/{pid}/task/{tid}/schedstat")
            if txt:
                total += int(txt.split()[0])
                ok = True
    except OSError:
        pass
    return total / 1e9 if ok else fallback_ticks / CLK_TCK


def kb_field(text, key):
    for line in text.splitlines():
        if line.startswith(key):
            return int(line.split()[1])
    return 0


def sample_tree(root):
    """Sample RSS/PSS/CPU/threads of root and all its descendants."""
    table = proc_table()
    children = {}
    for pid, (ppid, _) in table.items():
        children.setdefault(ppid, []).append(pid)
    tree, stack = [], [root]
    while stack:
        p = stack.pop()
        if p in table:
            tree.append(p)
            stack.extend(children.get(p, []))
    rss = pss = threads = 0
    cpu = 0.0
    for pid in tree:
        st = _read(f"/proc/{pid}/status")
        if not st:
            continue
        r = kb_field(st, "VmRSS:")
        rss += r
        threads += kb_field(st, "Threads:")
        sm = _read(f"/proc/{pid}/smaps_rollup")
        pss += kb_field(sm, "Pss:") if sm else r      # fallback: RSS
        cpu += cpu_seconds(pid, table[pid][1])
    return {"rss_kb": rss, "pss_kb": pss, "procs": len(tree),
            "threads": threads, "cpu_s": cpu}


# --------------------------------------------------------------------------
# one experiment
# --------------------------------------------------------------------------
def reader_thread(stream, q):
    for line in stream:
        q.put(line.rstrip("\n"))
    q.put(None)


def wait_line(q, prefix, timeout):
    end = time.time() + timeout
    while time.time() < end:
        try:
            line = q.get(timeout=0.5)
        except queue.Empty:
            continue
        if line is None:
            raise RuntimeError("load generator exited early")
        if line.startswith(prefix):
            return line
    raise TimeoutError(f"timeout waiting for {prefix}")


def run_one(model, n, a, port):
    srv = subprocess.Popen(
        [sys.executable, os.path.join(HERE, "servers.py"), "--model", model,
         "--port", str(port), "--thread-stack-kb", str(a.thread_stack_kb)],
        stdout=subprocess.PIPE, text=True, start_new_session=True)
    lg = None
    try:
        if "READY" not in srv.stdout.readline():
            raise RuntimeError("server failed to start")
        # Start the load generator FIRST (it waits idle) so that shared
        # library pages are split the same way in the baseline and later
        # samples; otherwise PSS would be skewed by who else maps them.
        lg = subprocess.Popen(
            [sys.executable, os.path.join(HERE, "loadgen.py"), "--gated",
             "--port", str(port), "--conns", str(n), "--requests",
             str(a.requests), "--think-ms", str(a.think_ms), "--msg-size",
             str(a.msg_size)],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
        q = queue.Queue()
        threading.Thread(target=reader_thread, args=(lg.stdout, q),
                         daemon=True).start()
        time.sleep(1.0)
        base = sample_tree(srv.pid)           # server alive, 0 connections
        lg.stdin.write("CONNECT\n"); lg.stdin.flush()

        parts = wait_line(q, "CONNECTED", 180).split()
        connected, conn_failed = int(parts[1]), int(parts[2])
        time.sleep(1.5)                       # let the server settle
        idle = sample_tree(srv.pid)           # all connections open, no traffic

        lg.stdin.write("GO\n"); lg.stdin.flush()
        peak = dict(idle)
        result = None
        while result is None:
            s = sample_tree(srv.pid)
            for k in ("rss_kb", "pss_kb", "procs", "threads"):
                peak[k] = max(peak[k], s[k])
            try:
                line = q.get(timeout=0.1)
            except queue.Empty:
                continue
            if line and line.startswith("RESULT"):
                result = json.loads(line[len("RESULT "):])
        end = sample_tree(srv.pid)            # connections still open
        cpu_load = max(0.0, end["cpu_s"] - idle["cpu_s"])

        lg.stdin.write("CLOSE\n"); lg.stdin.flush()
        lg.wait(timeout=30)
    finally:
        if lg and lg.poll() is None:
            lg.kill()
        try:
            os.killpg(srv.pid, signal.SIGTERM)
            srv.wait(timeout=10)
        except Exception:
            try:
                os.killpg(srv.pid, signal.SIGKILL)
            except Exception:
                pass
        time.sleep(0.5)

    mb = lambda kb: round(kb / 1024.0, 2)
    reqs = max(1, result["requests_ok"])
    return {
        "model": model, "conns": n, "connected": connected,
        "connect_failed": conn_failed,
        "base_rss_mb": mb(base["rss_kb"]), "base_pss_mb": mb(base["pss_kb"]),
        "idle_rss_mb": mb(idle["rss_kb"]), "idle_pss_mb": mb(idle["pss_kb"]),
        "peak_rss_mb": mb(peak["rss_kb"]), "peak_pss_mb": mb(peak["pss_kb"]),
        "pss_per_conn_kb": round((idle["pss_kb"] - base["pss_kb"]) /
                                 max(1, connected), 1),
        "peak_procs": peak["procs"], "peak_threads": peak["threads"],
        "throughput_rps": result["throughput_rps"],
        "lat_avg_ms": result["lat_avg_ms"], "lat_p50_ms": result["lat_p50_ms"],
        "lat_p95_ms": result["lat_p95_ms"], "lat_p99_ms": result["lat_p99_ms"],
        "lat_max_ms": result["lat_max_ms"],
        "errors": result["errors"],
        "cpu_s": round(cpu_load, 3),
        "cpu_ms_per_req": round(cpu_load * 1000.0 / reqs, 3),
    }


# --------------------------------------------------------------------------
# reporting
# --------------------------------------------------------------------------
def table(rows, cols, title):
    print(f"\n{title}")
    widths = [max(len(h), *(len(str(r[k])) for r in rows)) for h, k in cols]
    line = "  ".join(h.rjust(w) for (h, _), w in zip(cols, widths))
    print(line)
    print("-" * len(line))
    for r in rows:
        print("  ".join(str(r[k]).rjust(w) for (_, k), w in zip(cols, widths)))


def linfit(xs, ys):
    n = len(xs)
    mx, my = sum(xs) / n, sum(ys) / n
    den = sum((x - mx) ** 2 for x in xs)
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / den if den else 0
    return slope, my - slope * mx


def budget_analysis(rows, budgets_mb):
    print("\n=== MEMORY BUDGET ANALYSIS (linear model: PSS = a + b * connections) ===")
    print("a = fixed cost (MB), b = marginal cost per connection (KB), from idle PSS.")
    notes = {"select": "hard cap ~1020 fds (FD_SETSIZE) regardless of memory",
             "fork": "also bounded by max processes (ulimit -u / pid_max)",
             "thread": "also bounded by max threads / virtual memory",
             "epoll": "bounded by memory and file-descriptor limit only"}
    hdr = f"{'model':8} {'a (MB)':>8} {'b (KB/conn)':>12}"
    for b in budgets_mb:
        hdr += f" {'max conns @' + str(b) + 'MB':>20}"
    print(hdr)
    print("-" * len(hdr))
    for m in MODELS:
        pts = [r for r in rows if r["model"] == m]
        if not pts:
            continue
        xs = [0] + [r["connected"] for r in pts]
        ys = [pts[0]["base_pss_mb"] * 1024] + [r["idle_pss_mb"] * 1024 for r in pts]
        slope, icpt = linfit(xs, ys)
        line = f"{m:8} {icpt / 1024:8.1f} {slope:12.1f}"
        for b in budgets_mb:
            if slope > 1.0:
                line += f" {int((b * 1024 - icpt) / slope):20d}"
            else:
                line += f" {'not memory-bound':>20}"
        print(line)
    print()
    for m in MODELS:
        print(f"  note[{m}]: {notes[m]}")


def bars(rows, key, title, unit):
    print(f"\n{title}")
    nmax = max(r["conns"] for r in rows)
    sel = [r for r in rows if r["conns"] == nmax]
    top = max(r[key] for r in sel) or 1
    for r in sel:
        bar = "#" * int(40 * r[key] / top)
        print(f"  {r['model']:7} |{bar:<40}| {r[key]} {unit}  (N={nmax})")


def make_plot(rows, path):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("(matplotlib not installed - skipping chart)")
        return
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.5))
    specs = [("idle_pss_mb", "Memory (PSS, MB) with N idle connections"),
             ("throughput_rps", "Throughput (req/s)"),
             ("lat_p99_ms", "p99 latency (ms)")]
    for axis, (key, title) in zip(ax, specs):
        for m in MODELS:
            pts = [r for r in rows if r["model"] == m]
            if pts:
                axis.plot([r["conns"] for r in pts], [r[key] for r in pts],
                          marker="o", label=m)
        axis.set_title(title); axis.set_xlabel("concurrent connections")
        axis.grid(alpha=.3); axis.legend()
    fig.tight_layout(); fig.savefig(path, dpi=130)
    print(f"chart written to {path}")


# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="I/O model benchmark")
    ap.add_argument("--models", nargs="+", default=MODELS, choices=MODELS)
    ap.add_argument("--conns", nargs="+", type=int, default=[50, 200, 500])
    ap.add_argument("--requests", type=int, default=100)
    ap.add_argument("--think-ms", type=float, default=50)
    ap.add_argument("--msg-size", type=int, default=64)
    ap.add_argument("--thread-stack-kb", type=int, default=0)
    ap.add_argument("--budget-mb", nargs="+", type=int, default=[256, 1024])
    ap.add_argument("--port-base", type=int, default=9100)
    ap.add_argument("--out", default=os.path.join(HERE, "results"))
    a = ap.parse_args()

    if not sys.platform.startswith("linux"):
        sys.exit("Linux required (use WSL2 on Windows).")
    soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
    try:
        resource.setrlimit(resource.RLIMIT_NOFILE,
                           (65536 if hard == resource.RLIM_INFINITY else hard, hard))
    except (ValueError, OSError):
        pass

    print("I/O MODEL COMPARISON AND MEMORY BUDGET ANALYSIS")
    print(f"workload: {a.requests} x {a.msg_size}-byte echo per connection, "
          f"think time {a.think_ms} ms, N in {a.conns}")
    rows, port = [], a.port_base
    for n in a.conns:
        for m in a.models:
            port += 1
            print(f"  running model={m:6} conns={n:5} ...", end=" ", flush=True)
            try:
                r = run_one(m, n, a, port)
            except Exception as e:                      # keep going
                print(f"FAILED ({e})")
                continue
            rows.append(r)
            print(f"ok  rps={r['throughput_rps']}  pss={r['idle_pss_mb']}MB  "
                  f"conn_failed={r['connect_failed']} errors={r['errors']}")

    if not rows:
        sys.exit("no successful runs")
    order = {m: i for i, m in enumerate(MODELS)}
    rows.sort(key=lambda r: (r["conns"], order[r["model"]]))

    table(rows, [("model", "model"), ("N", "conns"), ("ok", "connected"),
                 ("base PSS", "base_pss_mb"), ("idle RSS", "idle_rss_mb"),
                 ("idle PSS", "idle_pss_mb"), ("peak PSS", "peak_pss_mb"),
                 ("KB/conn", "pss_per_conn_kb"), ("procs", "peak_procs"),
                 ("threads", "peak_threads")],
          "=== MEMORY (MB unless stated; PSS = fair figure) ===")
    table(rows, [("model", "model"), ("N", "conns"), ("req/s", "throughput_rps"),
                 ("avg ms", "lat_avg_ms"), ("p50 ms", "lat_p50_ms"),
                 ("p95 ms", "lat_p95_ms"), ("p99 ms", "lat_p99_ms"),
                 ("max ms", "lat_max_ms"), ("errors", "errors"),
                 ("CPU s", "cpu_s"), ("CPU ms/req", "cpu_ms_per_req")],
          "=== PERFORMANCE ===")
    bars(rows, "idle_pss_mb", "=== Memory at largest N (lower is better) ===", "MB")
    bars(rows, "throughput_rps", "=== Throughput at largest N ===", "req/s")
    budget_analysis(rows, a.budget_mb)

    with open(a.out + ".csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    with open(a.out + ".json", "w") as f:
        json.dump(rows, f, indent=2)
    print(f"\nresults written to {a.out}.csv and {a.out}.json")
    make_plot(rows, a.out + ".png")


if __name__ == "__main__":
    main()
